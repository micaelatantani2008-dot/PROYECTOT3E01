unit Practico0101;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, CADENA01;

type

  { TForm1 }

  TForm1 = class(TForm)
    BtnCargar: TButton;
    BtnInsertar: TButton;
    BtnEliminar: TButton;
    BtnBuscar: TButton;
    BtnCambiar: TButton;
    BtnContarPal: TButton;
    BtnAgregarPal: TButton;
    BtnAgregarChar: TButton;
    BtnInsertarChar: TButton;
    BtnEliminarChar: TButton;
    BtnInterChar: TButton;
    BtnObtenerChar: TButton;
    BtnContarChar: TButton;
    BtnBuscarChar: TButton;
    BtnInvertir: TButton;
    BtnRotar: TButton;
    BtnMinusculas: TButton;
    BtnTitulo: TButton;
    BtnMayuscula: TButton;
    EditBuscarChar: TEdit;
    EditPos2: TEdit;
    EditPosChar: TEdit;
    EditCaracter: TEdit;
    EditAgregarPal: TEdit;
    EditCambiar: TEdit;
    EditNueva: TEdit;
    EditBuscar: TEdit;
    EditEliminar: TEdit;
    EditCadena: TEdit;
    EditPalabra: TEdit;
    EditPos: TEdit;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Label4: TLabel;
    Label5: TLabel;
    Label6: TLabel;
    Label7: TLabel;
    Label8: TLabel;
    Labelnombre: TLabel;
    LabelCadena: TLabel;
    LabelPalabra: TLabel;
    LabelPos: TLabel;
    LabelResultado: TLabel;
    MemoResultado: TMemo;

  procedure FormCreate(Sender: TObject);
  procedure BtnCargarClick(Sender: TObject);
  procedure BtnInsertarClick(Sender: TObject);
  procedure BtnEliminarClick(Sender: TObject);
  procedure BtnBuscarClick(Sender: TObject);
  procedure BtnCambiarClick(Sender: TObject);
  procedure BtnContarPalClick(Sender: TObject);
  procedure BtnAgregarPalClick(Sender: TObject);
  procedure BtnAgregarCharClick(Sender: TObject);
  procedure BtnInsertarCharClick(Sender: TObject);
procedure BtnEliminarCharClick(Sender: TObject);
procedure BtnInterCharClick(Sender: TObject);
procedure BtnContarCharClick(Sender: TObject);
procedure BtnObtenerCharClick(Sender: TObject);
procedure BtnBuscarCharClick(Sender: TObject);
procedure BtnInvertirClick(Sender: TObject);
procedure BtnRotarClick(Sender: TObject);
procedure BtnMayusculasClick(Sender: TObject);
procedure BtnMinusculasClick(Sender: TObject);
procedure BtnTituloClick(Sender: TObject);
  private
     C: Cadena;
  public
  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

procedure TForm1.FormCreate(Sender: TObject);
begin
  C := Cadena.Crear;
end;

procedure TForm1.BtnCargarClick(Sender: TObject);
begin
  C.Cargar(EditCadena.Text);
  MemoResultado.Lines.Text := C.Mostrar;
end;

procedure TForm1.BtnInsertarClick(Sender: TObject);
var
  posi: integer;
begin
  posi := StrToIntDef(EditPos.Text, 0);

  if (posi < 1) or (posi > Length(C.Mostrar) + 1) then
  begin
    ShowMessage('Posicion incorrecta.');
    Exit;
  end;

  if Trim(EditPalabra.Text) = '' then
  begin
    ShowMessage('Escriba una palabra.');
    Exit;
  end;

  C.insPal(Trim(EditPalabra.Text), posi);
  MemoResultado.Lines.Text := C.Mostrar;
end;

procedure TForm1.BtnEliminarClick(Sender: TObject);
begin
  C.elimPal(Trim(EditEliminar.Text));
  MemoResultado.Lines.Text := C.Mostrar;
end;

procedure TForm1.BtnBuscarClick(Sender: TObject);
var
  posi: integer;
begin
  posi := C.buscPal(Trim(EditBuscar.Text));

  if posi > 0 then
    MemoResultado.Lines.Text :=
      'Palabra encontrada en la posicion: ' + IntToStr(posi)
  else
    MemoResultado.Lines.Text := 'Palabra no encontrada.';
end;

procedure TForm1.BtnCambiarClick(Sender: TObject);
begin
  if Trim(EditCambiar.Text) = '' then
  begin
    ShowMessage('Escriba la palabra que desea cambiar.');
    Exit;
  end;

  if Trim(EditNueva.Text) = '' then
  begin
    ShowMessage('Escriba la nueva palabra.');
    Exit;
  end;

  C.cambPal(Trim(EditCambiar.Text), Trim(EditNueva.Text));
  MemoResultado.Lines.Text := C.Mostrar;
end;

procedure TForm1.BtnContarPalClick(Sender: TObject);
begin
  MemoResultado.Lines.Text :=
    'Cantidad de palabras: ' + IntToStr(C.cantPal);
end;

procedure TForm1.BtnAgregarPalClick(Sender: TObject);
begin
  if Trim(EditAgregarPal.Text) = '' then
  begin
    ShowMessage('Escriba una palabra.');
    Exit;
  end;

  C.addPal(Trim(EditAgregarPal.Text));
  MemoResultado.Lines.Text := C.Mostrar;
end;

procedure TForm1.BtnAgregarCharClick(Sender: TObject);
var
  car: char;
begin
  if Trim(EditCaracter.Text) = '' then
  begin
    ShowMessage('Escriba un caracter.');
    Exit;
  end;

  car := EditCaracter.Text[1];
  C.addChar(car);
  MemoResultado.Lines.Text := C.Mostrar;
end;

procedure TForm1.BtnInsertarCharClick(Sender: TObject);
var
  p: integer;
begin
  p := StrToIntDef(EditPosChar.Text, 0);
  if (p < 1) or (p > Length(C.Mostrar) + 1) then
  begin
    ShowMessage('Posicion incorrecta.');
    Exit;
  end;

  C.insChar('*', p);
  MemoResultado.Lines.Text := C.Mostrar;
end;


procedure TForm1.BtnEliminarCharClick(Sender: TObject);
var
  p: integer;
begin
  p := StrToIntDef(EditPosChar.Text, 0);
  if (p < 1) or (p > Length(C.Mostrar)) then
  begin
    ShowMessage('Posicion incorrecta.');
    Exit;
  end;

  C.elimChar(p);
  MemoResultado.Lines.Text := C.Mostrar;
end;


procedure TForm1.BtnInterCharClick(Sender: TObject);
var
  p1, p2: integer;
begin
  p1 := StrToIntDef(EditPosChar.Text, 0);
  p2 := StrToIntDef(EditPos2.Text, 0);

  if (p1 < 1) or (p1 > Length(C.Mostrar)) or
     (p2 < 1) or (p2 > Length(C.Mostrar)) then
  begin
    ShowMessage('Una de las posiciones es incorrecta.');
    Exit;
  end;

  C.interChar(p1, p2);
  MemoResultado.Lines.Text := C.Mostrar;
end;


procedure TForm1.BtnContarCharClick(Sender: TObject);
begin
  MemoResultado.Lines.Text :=
    'Cantidad de caracteres: ' + IntToStr(C.cantChar);
end;


procedure TForm1.BtnObtenerCharClick(Sender: TObject);
var
  p: integer;
  car: char;
begin
  p := StrToIntDef(EditPosChar.Text, 0);

  if (p < 1) or (p > Length(C.Mostrar)) then
  begin
    ShowMessage('Posicion incorrecta.');
    Exit;
  end;

  car := C.getChar(p);
  MemoResultado.Lines.Text := 'Caracter: ' + car;
end;


procedure TForm1.BtnBuscarCharClick(Sender: TObject);
var
  p: integer;
begin
  if Trim(EditBuscarChar.Text) = '' then
  begin
    ShowMessage('Escriba un caracter.');
    Exit;
  end;

  p := C.busqChar(EditBuscarChar.Text[1]);

  if p > 0 then
    MemoResultado.Lines.Text :=
      'Caracter encontrado en la posicion: ' + IntToStr(p)
  else
    MemoResultado.Lines.Text := 'Caracter no encontrado.';
end;


procedure TForm1.BtnInvertirClick(Sender: TObject);
begin
  C.invertir;
  MemoResultado.Lines.Text := C.Mostrar;
end;


procedure TForm1.BtnRotarClick(Sender: TObject);
begin
  C.rotar;
  MemoResultado.Lines.Text := C.Mostrar;
end;


procedure TForm1.BtnMayusculasClick(Sender: TObject);
begin
  C.Mayusculas;
  MemoResultado.Lines.Text := C.Mostrar;
end;


procedure TForm1.BtnMinusculasClick(Sender: TObject);
begin
  C.Minusculas;
  MemoResultado.Lines.Text := C.Mostrar;
end;


procedure TForm1.BtnTituloClick(Sender: TObject);
begin
  C.Titulo;
  MemoResultado.Lines.Text := C.Mostrar;
end;

end.

