unit CADENA01;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils;

type
  Cadena = class
  private
    cad: string;
  public
    constructor Crear;
    procedure Cargar(texto: string);
    function Mostrar: string;

    procedure addChar(car: char);
    procedure insChar(car: char; pos: integer);
    procedure elimChar(pos: integer);
    procedure interChar(pos1, pos2: integer);
    function cantChar: integer;
    function getChar(pos: integer): char;
    function busqChar(car: char): integer;

    function cantPal: integer;
    procedure insPal(pal: string; pos: integer);
    procedure elimPal(pal: string);
    procedure cambPal(pal1, pal2: string);
    function buscPal(pal: string): integer;
    procedure addPal(pal: string);

    procedure invertir;
    procedure rotar;
    procedure Mayusculas;
    procedure Minusculas;
    procedure Titulo;
  end;

implementation

constructor Cadena.Crear;
begin
  cad := '';
end;

procedure Cadena.Cargar(texto: string);
begin
  cad := texto;
end;

function Cadena.Mostrar: string;
begin
  Mostrar := cad;
end;

procedure Cadena.addChar(car: char);
begin
  cad := cad + car;
end;

procedure Cadena.insChar(car: char; pos: integer);
begin
  if (pos >= 1) and (pos <= Length(cad) + 1) then
    Insert(car, cad, pos);
end;

procedure Cadena.elimChar(pos: integer);
begin
  if (pos >= 1) and (pos <= Length(cad)) then
    Delete(cad, pos, 1);
end;

procedure Cadena.interChar(pos1, pos2: integer);
var
  aux: char;
begin
  if (pos1 >= 1) and (pos1 <= Length(cad)) and
     (pos2 >= 1) and (pos2 <= Length(cad)) then
  begin
    aux := cad[pos1];
    cad[pos1] := cad[pos2];
    cad[pos2] := aux;
  end;
end;

function Cadena.cantChar: integer;
begin
  cantChar := Length(cad);
end;

function Cadena.getChar(pos: integer): char;
begin
  getChar := #0;
  if (pos >= 1) and (pos <= Length(cad)) then
    getChar := cad[pos];
end;

function Cadena.busqChar(car: char): integer;
begin
  busqChar := Pos(car, cad);
end;

function Cadena.cantPal: integer;
var
  i: integer;
  dentro: boolean;
begin
  cantPal := 0;
  dentro := false;

  for i := 1 to Length(cad) do
  begin
    if cad[i] <> ' ' then
    begin
      if not dentro then
      begin
        cantPal := cantPal + 1;
        dentro := true;
      end;
    end
    else
      dentro := false;
  end;
end;

procedure Cadena.insPal(pal: string; pos: integer);
begin
  if (pos >= 1) and (pos <= Length(cad) + 1) then
  begin
    Insert(pal, cad, pos);

    if (pos > 1) and (cad[pos - 1] <> ' ') then
      Insert(' ', cad, pos);

    if (pos + Length(pal) <= Length(cad)) and
       (cad[pos + Length(pal)] <> ' ') then
      Insert(' ', cad, pos + Length(pal));
  end;
end;

procedure Cadena.elimPal(pal: string);
var
  p: integer;
begin
  p := Pos(pal, cad);
  if p > 0 then
  begin
    Delete(cad, p, Length(pal));
    cad := Trim(cad);
  end;
end;

procedure Cadena.cambPal(pal1, pal2: string);
var
  p: integer;
begin
  p := Pos(pal1, cad);
  if (p > 0) and (pal1 <> '') then
  begin
    Delete(cad, p, Length(pal1));
    Insert(pal2, cad, p);
  end;
end;

function Cadena.buscPal(pal: string): integer;
begin
  buscPal := Pos(pal, cad);
end;

procedure Cadena.addPal(pal: string);
begin
  if cad <> '' then
    cad := cad + ' ';
  cad := cad + pal;
end;

procedure Cadena.invertir;
var
  i: integer;
  aux: string;
begin
  aux := '';
  for i := Length(cad) downto 1 do
    aux := aux + cad[i];
  cad := aux;
end;

procedure Cadena.rotar;
var
  aux: char;
begin
  if Length(cad) > 1 then
  begin
    aux := cad[1];
    Delete(cad, 1, 1);
    cad := cad + aux;
  end;
end;

procedure Cadena.Mayusculas;
begin
  cad := UpperCase(cad);
end;

procedure Cadena.Minusculas;
begin
  cad := LowerCase(cad);
end;

procedure Cadena.Titulo;
var
  i: integer;
begin
  cad := LowerCase(cad);

  if Length(cad) > 0 then
    cad[1] := UpCase(cad[1]);

  for i := 2 to Length(cad) do
    if (cad[i - 1] = ' ') and (cad[i] <> ' ') then
      cad[i] := UpCase(cad[i]);
end;

end.

